package com.hibernatestandalone.HibernateStandalone;

public enum EstadoReserva {
    CONFIRMADA,
    CANCELADA,
    CHECK_IN,
    CHECK_OUT 
}
