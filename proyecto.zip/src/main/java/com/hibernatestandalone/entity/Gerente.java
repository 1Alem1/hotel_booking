
package com.hibernatestandalone.entity;

import jakarta.persistence.Entity;

@Entity
public class Gerente extends Usuario {
    
}
