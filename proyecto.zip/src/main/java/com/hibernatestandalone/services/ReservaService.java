package com.hibernatestandalone.services;

import com.hibernatestandalone.entity.Reserva;
import com.hibernatestandalone.services.AbstractService;
import com.hibernatestandalone.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class ReservaService extends AbstractService {

    
}